<?php
/**
 * database.php
 * データベース接続情報などをまとめる設定ファイル
 * 実運用では .env に記載し、ここで読み込む形などが推奨です
 */

return [
    'host' => 'mysql3103.db.sakura.ne.jp',
    'dbname' => 'portfolio-t_tango',
    'username' => 'portfolio-t_tango',
    'password' => '5693-dennou',
    'charset' => 'utf8mb4',
];
